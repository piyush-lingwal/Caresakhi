import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Sparkles, Leaf, Shield, Download, Smartphone, Play, Star, Heart, Zap, Award, Users, TrendingUp, Target, ShoppingCart } from 'lucide-react';

const Hero = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);
  
  const heroContent = [
    {
      title: "Your Trusted Period Companion",
      subtitle: "Sustainable • Comfortable • Empowering",
      description: "Join thousands of women who trust CareSakhi for their menstrual health. Better for you, better for the planet.",
      cta: "Shop Now",
      ctaSecondary: "Track Period",
      stats: { users: "50,000+", satisfaction: "98%", savings: "₹2,000" }
    },
    {
      title: "Up to 10 Years of Protection",
      subtitle: "Premium Quality • Cost Effective",
      description: "Our medical-grade silicone cups and innovative period underwear provide long-lasting comfort and reliability.",
      cta: "Explore Products",
      ctaSecondary: "Learn More",
      stats: { lifespan: "10 Years", protection: "12 Hours", eco: "Zero Waste" }
    },
    {
      title: "Revolutionizing Women's Health",
      subtitle: "Innovation • Science • Care",
      description: "Advanced technology meets traditional care. Experience the future of menstrual health with our award-winning products.",
      cta: "Get Started",
      ctaSecondary: "Watch Demo",
      stats: { awards: "15+", research: "5 Years", patents: "3 Filed" }
    }
  ];

  const floatingElements = [
    { icon: Heart, color: 'text-pink-400', size: 'w-6 h-6', delay: '0s', position: 'top-1/4 right-1/4' },
    { icon: Sparkles, color: 'text-purple-400', size: 'w-8 h-8', delay: '1s', position: 'bottom-1/3 left-1/3' },
    { icon: Leaf, color: 'text-green-400', size: 'w-7 h-7', delay: '2s', position: 'top-1/3 left-1/5' },
    { icon: Star, color: 'text-yellow-400', size: 'w-5 h-5', delay: '1.5s', position: 'bottom-1/4 right-1/3' },
    { icon: Shield, color: 'text-blue-400', size: 'w-6 h-6', delay: '2.5s', position: 'top-1/2 right-1/5' },
    { icon: Zap, color: 'text-orange-400', size: 'w-5 h-5', delay: '0.5s', position: 'bottom-1/2 left-1/4' }
  ];

  const testimonialCards = [
    { name: "Sarah J.", text: "Life-changing!", rating: 5, avatar: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100" },
    { name: "Emma R.", text: "Best decision ever", rating: 5, avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100" },
    { name: "Lisa C.", text: "Incredible comfort", rating: 5, avatar: "https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=100" }
  ];

  useEffect(() => {
    setIsVisible(true);
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroContent.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const currentContent = heroContent[currentSlide];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-pink-50 via-white to-purple-50">
      {/* Dynamic Animated Background */}
      <div className="absolute inset-0 opacity-30">
        {/* Gradient Orbs with Mouse Parallax */}
        <div 
          className="absolute w-96 h-96 bg-gradient-to-r from-pink-300 to-purple-300 rounded-full blur-3xl animate-pulse"
          style={{
            top: '10%',
            left: '5%',
            transform: `translate(${mousePosition.x * 0.02}px, ${mousePosition.y * 0.02}px)`
          }}
        ></div>
        <div 
          className="absolute w-80 h-80 bg-gradient-to-r from-purple-300 to-blue-300 rounded-full blur-3xl animate-pulse"
          style={{
            bottom: '15%',
            right: '10%',
            animationDelay: '2s',
            transform: `translate(${mousePosition.x * -0.015}px, ${mousePosition.y * -0.015}px)`
          }}
        ></div>
        <div 
          className="absolute w-64 h-64 bg-gradient-to-r from-green-300 to-teal-300 rounded-full blur-3xl animate-pulse"
          style={{
            top: '50%',
            left: '20%',
            animationDelay: '4s',
            transform: `translate(${mousePosition.x * 0.01}px, ${mousePosition.y * 0.01}px)`
          }}
        ></div>

        {/* Floating Geometric Shapes */}
        <div className="absolute top-20 left-20 w-4 h-4 bg-pink-400 rounded-full animate-bounce opacity-60" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-32 right-32 w-6 h-6 bg-purple-400 rotate-45 animate-pulse opacity-50" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/3 right-20 w-3 h-3 bg-blue-400 rounded-full animate-ping opacity-40" style={{ animationDelay: '3s' }}></div>
      </div>

      {/* Floating Icons */}
      {floatingElements.map((element, index) => {
        const IconComponent = element.icon;
        return (
          <div
            key={index}
            className={`absolute ${element.position} animate-float opacity-20 hover:opacity-40 transition-opacity duration-500`}
            style={{ animationDelay: element.delay }}
          >
            <IconComponent className={`${element.size} ${element.color}`} />
          </div>
        );
      })}

      <div className="container mx-auto px-4 py-32 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-12 gap-16 items-center">
            {/* Enhanced Content Section */}
            <div className="lg:col-span-7 text-center lg:text-left space-y-10">
              {/* Animated Badge */}
              <div className={`inline-flex items-center space-x-3 bg-white/80 backdrop-blur-lg text-pink-800 px-6 py-4 rounded-full text-lg font-semibold shadow-2xl border border-pink-200 transition-all duration-1000 ${isVisible ? 'animate-bounce-subtle opacity-100' : 'opacity-0'}`}>
                <div className="flex items-center space-x-2">
                  <div className="flex -space-x-2">
                    {testimonialCards.map((testimonial, i) => (
                      <img
                        key={i}
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-8 h-8 rounded-full border-2 border-white shadow-lg"
                      />
                    ))}
                  </div>
                  <Sparkles className="w-6 h-6 text-pink-600 animate-pulse" />
                </div>
                <span>Trusted by 50,000+ Women</span>
              </div>
              
              {/* Dynamic Title with Typewriter Effect */}
              <div className="space-y-6">
                <h1 className={`text-6xl lg:text-8xl font-bold leading-tight transition-all duration-1000 ${isVisible ? 'animate-fade-in' : 'opacity-0 translate-y-10'}`}>
                  <span className="bg-gradient-to-r from-pink-600 via-purple-600 to-pink-600 bg-clip-text text-transparent bg-300% animate-gradient">
                    {currentContent.title}
                  </span>
                </h1>
                
                <p className={`text-2xl lg:text-3xl font-bold text-gray-700 transition-all duration-1000 delay-300 ${isVisible ? 'animate-slide-up' : 'opacity-0 translate-y-10'}`}>
                  {currentContent.subtitle}
                </p>
                
                <p className={`text-xl lg:text-2xl text-gray-600 max-w-3xl mx-auto lg:mx-0 leading-relaxed transition-all duration-1000 delay-500 ${isVisible ? 'animate-fade-in' : 'opacity-0'}`}>
                  {currentContent.description}
                </p>
              </div>

              {/* Enhanced CTA Buttons */}
              <div className={`flex flex-col sm:flex-row gap-6 justify-center lg:justify-start transition-all duration-1000 delay-700 ${isVisible ? 'animate-slide-up' : 'opacity-0 translate-y-10'}`}>
                <Link
                  to="/products"
                  className="group relative bg-gradient-to-r from-pink-600 via-purple-600 to-pink-600 bg-300% animate-gradient text-white px-10 py-5 rounded-full font-bold text-xl transition-all duration-500 hover:shadow-2xl hover:scale-110 transform inline-flex items-center justify-center overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-700 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <span className="relative flex items-center justify-center space-x-3">
                    <span>{currentContent.cta}</span>
                    <ChevronDown className="w-6 h-6 rotate-[-90deg] group-hover:translate-x-2 transition-transform duration-300" />
                  </span>
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity duration-300 rounded-full"></div>
                </Link>
                
                <Link
                  to="/period-tracker"
                  className="group border-3 border-gray-300 text-gray-700 px-10 py-5 rounded-full font-bold text-xl hover:border-emerald-500 hover:text-emerald-600 hover:bg-emerald-50 transition-all duration-500 hover:shadow-xl hover:scale-105 inline-flex items-center justify-center relative overflow-hidden"
                >
                  <span className="relative z-10">{currentContent.ctaSecondary}</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-500 opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
                </Link>
              </div>

              {/* Dynamic Stats */}
              <div className={`flex flex-wrap justify-center lg:justify-start gap-8 pt-8 transition-all duration-1000 delay-900 ${isVisible ? 'animate-fade-in' : 'opacity-0'}`}>
                {Object.entries(currentContent.stats).map(([key, value], index) => (
                  <div key={key} className="text-center group hover:scale-110 transition-transform duration-300">
                    <div className="text-3xl lg:text-4xl font-bold text-pink-600 mb-2 group-hover:text-purple-600 transition-colors">
                      {value}
                    </div>
                    <div className="text-gray-600 font-medium capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </div>
                  </div>
                ))}
              </div>

              {/* Enhanced Key Benefits */}
              <div className={`flex flex-wrap justify-center lg:justify-start gap-8 pt-8 transition-all duration-1000 delay-1100 ${isVisible ? 'animate-slide-up' : 'opacity-0 translate-y-10'}`}>
                {[
                  { icon: Leaf, text: 'Eco-Friendly', color: 'text-green-500' },
                  { icon: Shield, text: 'Medical Grade', color: 'text-blue-500' },
                  { icon: Sparkles, text: '12hr Protection', color: 'text-purple-500' },
                  { icon: Award, text: 'Award Winning', color: 'text-orange-500' }
                ].map((benefit, index) => {
                  const IconComponent = benefit.icon;
                  return (
                    <div key={index} className="flex items-center space-x-3 text-gray-600 group hover:scale-110 transition-all duration-300">
                      <div className="p-3 bg-white/80 backdrop-blur-sm rounded-full shadow-lg group-hover:shadow-xl transition-shadow">
                        <IconComponent className={`w-6 h-6 ${benefit.color} group-hover:scale-125 transition-transform duration-300`} />
                      </div>
                      <span className="font-semibold text-lg group-hover:text-gray-800 transition-colors">{benefit.text}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Enhanced Hero Visual Section */}
            <div className="lg:col-span-5 relative">
              {/* Main Product Showcase */}
              <div className="relative z-10 transform hover:scale-105 transition-transform duration-700 mx-auto max-w-lg">
                <div className="aspect-square bg-gradient-to-br from-pink-100 via-white to-purple-100 rounded-3xl p-8 shadow-2xl backdrop-blur-lg border border-white/50 relative overflow-hidden">
                  {/* Animated Background Pattern */}
                  <div className="absolute inset-0 opacity-10">
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-pink-200 to-purple-200 rounded-3xl animate-pulse"></div>
                  </div>
                  
                  {/* Product Image with Hover Effects */}
                  <div className="relative z-10 group">
                    <img 
                      src="https://images.pexels.com/photos/7319070/pexels-photo-7319070.jpeg?auto=compress&cs=tinysrgb&w=800"
                      alt="Sustainable menstrual products"
                      className="w-full h-full object-cover rounded-2xl shadow-xl group-hover:shadow-2xl transition-shadow duration-500"
                    />
                    
                    {/* Overlay with Product Info */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <div className="absolute bottom-6 left-6 right-6 text-white">
                        <h3 className="text-2xl font-bold mb-2">Premium Collection</h3>
                        <p className="text-lg opacity-90">Medical-grade silicone products</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Clean Floating Stats Cards */}
              <div className="absolute -top-6 -right-6 bg-white/95 backdrop-blur-lg rounded-2xl p-4 shadow-xl animate-float border border-pink-200 hover:shadow-2xl transition-all duration-500 group">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-3">
                    <Award className="w-8 h-8 text-pink-600 group-hover:scale-125 transition-transform duration-300" />
                    <div className="text-2xl font-bold text-pink-600 group-hover:text-purple-600 transition-colors">10+</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-800">Years Protection</div>
                  <div className="text-sm text-gray-600">Lifetime Value</div>
                </div>
              </div>
              
              <div className="absolute -bottom-6 -left-6 bg-white/95 backdrop-blur-lg rounded-2xl p-4 shadow-xl animate-float-delay border border-purple-200 hover:shadow-2xl transition-all duration-500 group">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-3">
                    <TrendingUp className="w-8 h-8 text-purple-600 group-hover:scale-125 transition-transform duration-300" />
                    <div className="text-2xl font-bold text-purple-600 group-hover:text-pink-600 transition-colors">₹2,000</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-800">Lifetime Savings</div>
                  <div className="text-sm text-gray-600">Cost Effective</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced App Download Section */}
        <div className={`mt-20 bg-white/95 backdrop-blur-xl rounded-3xl p-8 lg:p-12 shadow-2xl border border-white/50 transition-all duration-1000 delay-1300 ${isVisible ? 'animate-scale-in' : 'opacity-0 scale-95'}`}>
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-4 bg-gradient-to-r from-pink-100 to-purple-100 rounded-2xl">
                  <Smartphone className="w-10 h-10 text-pink-600" />
                </div>
                <div>
                  <h3 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-2">
                    Download CareSakhi App
                  </h3>
                  <p className="text-lg lg:text-xl text-gray-600">
                    Track your periods, get personalized insights, and shop seamlessly
                  </p>
                </div>
              </div>
            </div>
            
            {/* Enhanced App Download Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
              <button className="group relative bg-gradient-to-r from-pink-600 via-purple-600 to-pink-600 bg-300% animate-gradient text-white px-10 py-5 rounded-2xl font-bold text-xl hover:shadow-2xl transition-all duration-500 flex items-center justify-center space-x-4 hover:scale-110 transform overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-pink-700 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative flex items-center space-x-4">
                  <div className="p-2 bg-white/20 rounded-xl">
                    <Download className="w-8 h-8 group-hover:animate-bounce" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm opacity-90">Download on the</div>
                    <div className="text-xl font-bold">App Store</div>
                  </div>
                </div>
                <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300 rounded-2xl"></div>
              </button>
              
              <button className="group relative bg-gradient-to-r from-green-600 via-emerald-600 to-green-600 bg-300% animate-gradient text-white px-10 py-5 rounded-2xl font-bold text-xl hover:shadow-2xl transition-all duration-500 flex items-center justify-center space-x-4 hover:scale-110 transform overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-green-700 to-emerald-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative flex items-center space-x-4">
                  <div className="p-2 bg-white/20 rounded-xl">
                    <Smartphone className="w-8 h-8 group-hover:animate-pulse" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm opacity-90">Get it on</div>
                    <div className="text-xl font-bold">Google Play</div>
                  </div>
                </div>
                <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300 rounded-2xl"></div>
              </button>
              
              <button className="group border-3 border-gray-300 text-gray-700 px-10 py-5 rounded-2xl font-bold text-xl hover:border-pink-500 hover:text-pink-600 hover:bg-pink-50 transition-all duration-500 flex items-center justify-center space-x-4 hover:scale-110 relative overflow-hidden">
                <div className="relative z-10 flex items-center space-x-4">
                  <div className="p-2 bg-gray-100 group-hover:bg-pink-100 rounded-xl transition-colors">
                    <Play className="w-8 h-8 group-hover:text-pink-600 transition-colors" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm text-gray-500 group-hover:text-pink-500">Watch our</div>
                    <div className="text-xl font-bold">Demo Video</div>
                  </div>
                </div>
                <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </button>
            </div>

            {/* App Features Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Target, text: 'Period Tracking', color: 'pink', desc: 'Smart predictions' },
                { icon: ShoppingCart, text: 'Easy Shopping', color: 'purple', desc: 'One-click orders' },
                { icon: Heart, text: 'Health Insights', color: 'green', desc: 'Personalized tips' },
                { icon: Users, text: 'Community', color: 'blue', desc: 'Support network' }
              ].map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <div key={index} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-white/50">
                    <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-${feature.color}-100 to-${feature.color}-200 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <IconComponent className={`w-8 h-8 text-${feature.color}-600`} />
                    </div>
                    <h4 className="text-lg font-bold text-gray-800 mb-2">{feature.text}</h4>
                    <p className="text-sm text-gray-600">{feature.desc}</p>
                  </div>
                );
              })}
            </div>

            {/* Trust Indicators */}
            <div className="mt-12 text-center">
              <div className="flex items-center justify-center space-x-8 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-green-600" />
                  <span>Secure & Encrypted</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="w-5 h-5 text-yellow-500" />
                  <span>4.9★ App Rating</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Download className="w-5 h-5 text-blue-600" />
                  <span>100K+ Downloads</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Slide Indicators */}
        <div className="flex justify-center space-x-4 mt-16">
          {heroContent.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-4 h-4 rounded-full transition-all duration-500 hover:scale-125 ${
                index === currentSlide
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 w-12 shadow-lg'
                  : 'bg-gray-300 hover:bg-gray-400'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Enhanced Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce group cursor-pointer">
        <div className="bg-white/80 backdrop-blur-sm rounded-full p-4 shadow-xl group-hover:shadow-2xl transition-shadow duration-300">
          <ChevronDown className="w-8 h-8 text-gray-600 group-hover:text-pink-600 transition-colors" />
        </div>
      </div>

      {/* Particle Animation */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-pink-400 rounded-full opacity-30 animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          ></div>
        ))}
      </div>
    </section>
  );
};

export default Hero;